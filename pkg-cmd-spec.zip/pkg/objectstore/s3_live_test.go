package objectstore_test

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"io"
	"net/http"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/lennylabs/podium/pkg/objectstore"
)

// liveS3 reads PODIUM_S3_* env vars and returns a configured S3
// Provider, or skips when the environment is unconfigured. The
// recommended free target for nightly CI is play.min.io with the
// publicly-known credentials (kept stable by MinIO for testing):
//
//	PODIUM_S3_ENDPOINT=https://play.min.io
//	PODIUM_S3_BUCKET=podium-ci
//	PODIUM_S3_REGION=us-east-1
//	PODIUM_S3_ACCESS_KEY_ID=Q3AM3UQ867SPQQA43P2F
//	PODIUM_S3_SECRET_ACCESS_KEY=zuf+tfteSlswRu7BJ86wekitnifILbZam1KYY3TG
//
// Local devs running MinIO themselves point the endpoint at
// http://localhost:9000 (the http scheme selects plaintext). Production
// smokes use AWS S3 with a CI service account.
// liveS3Config reads the PODIUM_S3_* environment into an S3Config. TLS is
// derived from the endpoint URL scheme via ParseS3Endpoint (§13.12). The ok
// return is false when ENDPOINT or BUCKET is missing; the live tests skip in
// that case. Anonymous access (no creds) is intentional for endpoints that
// permit it.
func liveS3Config() (objectstore.S3Config, bool) {
	endpoint := os.Getenv("PODIUM_S3_ENDPOINT")
	bucket := os.Getenv("PODIUM_S3_BUCKET")
	if endpoint == "" || bucket == "" {
		return objectstore.S3Config{}, false
	}
	host, useSSL := objectstore.ParseS3Endpoint(endpoint)
	return objectstore.S3Config{
		Endpoint:        host,
		Bucket:          bucket,
		Region:          envOr("PODIUM_S3_REGION", "us-east-1"),
		AccessKeyID:     os.Getenv("PODIUM_S3_ACCESS_KEY_ID"),
		SecretAccessKey: os.Getenv("PODIUM_S3_SECRET_ACCESS_KEY"),
		UseSSL:          useSSL,
	}, true
}

func liveS3(t *testing.T) *objectstore.S3 {
	t.Helper()
	cfg, ok := liveS3Config()
	if !ok {
		t.Skip("PODIUM_S3_ENDPOINT/BUCKET unset; skipping live S3 smoke")
	}
	s3, err := objectstore.NewS3(cfg)
	if err != nil {
		t.Skipf("NewS3: %v", err)
	}
	return s3
}

func envOr(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

// Spec: n/a — liveS3Config's env-var resolution. The integration tests
// above gate on a real S3 endpoint; this test exercises the resolution
// branch independently using t.Setenv.
func TestLiveS3Config_Resolution(t *testing.T) {
	// Every t.Setenv call below explicitly clears the variable for the
	// duration of the test, so a developer's exported PODIUM_S3_* vars
	// don't leak in.
	resetEnv := func(t *testing.T) {
		for _, k := range []string{
			"PODIUM_S3_ENDPOINT", "PODIUM_S3_BUCKET", "PODIUM_S3_REGION",
			"PODIUM_S3_ACCESS_KEY_ID", "PODIUM_S3_SECRET_ACCESS_KEY",
		} {
			t.Setenv(k, "")
		}
	}

	t.Run("missing endpoint", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_BUCKET", "b")
		if _, ok := liveS3Config(); ok {
			t.Error("ok = true, want false when endpoint is unset")
		}
	})

	t.Run("missing bucket", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_ENDPOINT", "host:9000")
		if _, ok := liveS3Config(); ok {
			t.Error("ok = true, want false when bucket is unset")
		}
	})

	t.Run("region defaults to us-east-1", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_ENDPOINT", "host:9000")
		t.Setenv("PODIUM_S3_BUCKET", "b")
		cfg, ok := liveS3Config()
		if !ok || cfg.Region != "us-east-1" {
			t.Errorf("Region = %q (ok=%v), want us-east-1, true", cfg.Region, ok)
		}
	})

	t.Run("region from env", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_ENDPOINT", "host:9000")
		t.Setenv("PODIUM_S3_BUCKET", "b")
		t.Setenv("PODIUM_S3_REGION", "eu-west-1")
		cfg, _ := liveS3Config()
		if cfg.Region != "eu-west-1" {
			t.Errorf("Region = %q, want eu-west-1", cfg.Region)
		}
	})

	t.Run("anonymous when creds unset", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_ENDPOINT", "host:9000")
		t.Setenv("PODIUM_S3_BUCKET", "b")
		cfg, _ := liveS3Config()
		if cfg.AccessKeyID != "" || cfg.SecretAccessKey != "" {
			t.Errorf("creds = (%q, %q), want both empty", cfg.AccessKeyID, cfg.SecretAccessKey)
		}
	})

	t.Run("credentialed when creds set", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_ENDPOINT", "host:9000")
		t.Setenv("PODIUM_S3_BUCKET", "b")
		t.Setenv("PODIUM_S3_ACCESS_KEY_ID", "AKIA…")
		t.Setenv("PODIUM_S3_SECRET_ACCESS_KEY", "secret")
		cfg, _ := liveS3Config()
		if cfg.AccessKeyID != "AKIA…" || cfg.SecretAccessKey != "secret" {
			t.Errorf("creds = (%q, %q)", cfg.AccessKeyID, cfg.SecretAccessKey)
		}
	})

	t.Run("TLS on by default for a bare host", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_ENDPOINT", "host:9000")
		t.Setenv("PODIUM_S3_BUCKET", "b")
		cfg, _ := liveS3Config()
		if !cfg.UseSSL {
			t.Error("UseSSL = false, want true (default)")
		}
	})

	t.Run("TLS off for an http endpoint", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_ENDPOINT", "http://host:9000")
		t.Setenv("PODIUM_S3_BUCKET", "b")
		cfg, _ := liveS3Config()
		if cfg.UseSSL {
			t.Error("UseSSL = true, want false (http scheme)")
		}
		if cfg.Endpoint != "host:9000" {
			t.Errorf("Endpoint = %q, want host:9000 (scheme stripped)", cfg.Endpoint)
		}
	})

	t.Run("TLS on for an https endpoint", func(t *testing.T) {
		resetEnv(t)
		t.Setenv("PODIUM_S3_ENDPOINT", "https://host:9000")
		t.Setenv("PODIUM_S3_BUCKET", "b")
		cfg, _ := liveS3Config()
		if !cfg.UseSSL {
			t.Error("UseSSL = false, want true (https scheme)")
		}
	})
}

// uniqueKey returns a random key prefix so concurrent CI jobs don't
// collide on the shared test bucket.
func uniqueKey(t *testing.T, suffix string) string {
	t.Helper()
	buf := make([]byte, 8)
	if _, err := rand.Read(buf); err != nil {
		t.Fatalf("rand: %v", err)
	}
	return "podium-test/" + hex.EncodeToString(buf) + "/" + suffix
}

// Spec: §13.10 — S3 backend round-trip end-to-end against a live
// S3-compatible endpoint. Gated on PODIUM_S3_* env vars; default
// CI runs skip the test.
func TestS3_LivePutGetRoundTrip(t *testing.T) {
	s := liveS3(t)
	ctx := context.Background()
	key := uniqueKey(t, "round-trip")
	body := []byte("podium live S3 smoke " + key)
	if err := s.Put(ctx, key, body, "text/plain"); err != nil {
		t.Fatalf("Put: %v", err)
	}
	t.Cleanup(func() { _ = s.Delete(ctx, key) })

	got, err := s.Get(ctx, key)
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	if string(got) != string(body) {
		t.Errorf("Get returned %q, want %q", got, body)
	}
}

// Spec: §6.2 — S3.Presign returns a Signature V4 URL the consumer
// can follow to fetch the body without sending credentials. Tests
// use a real http.Client so the signature is exercised end-to-end.
func TestS3_LivePresignRoundTrip(t *testing.T) {
	s := liveS3(t)
	ctx := context.Background()
	key := uniqueKey(t, "presign")
	body := []byte("presigned content")
	if err := s.Put(ctx, key, body, "text/plain"); err != nil {
		t.Fatalf("Put: %v", err)
	}
	t.Cleanup(func() { _ = s.Delete(ctx, key) })

	url, err := s.Presign(ctx, key, 5*time.Minute)
	if err != nil {
		t.Fatalf("Presign: %v", err)
	}
	if !strings.Contains(url, "X-Amz-Signature=") {
		t.Errorf("Presign URL missing AWS signature: %s", url)
	}
	resp, err := http.Get(url)
	if err != nil {
		t.Fatalf("GET presigned: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("presigned GET status = %d", resp.StatusCode)
	}
	got, _ := io.ReadAll(resp.Body)
	if string(got) != string(body) {
		t.Errorf("presigned GET returned %q, want %q", got, body)
	}
}

// Spec: §6.10 — S3.Get on a missing key returns ErrNotFound.
func TestS3_LiveGetMissingReturnsErrNotFound(t *testing.T) {
	s := liveS3(t)
	_, err := s.Get(context.Background(), uniqueKey(t, "definitely-missing"))
	if !errors.Is(err, objectstore.ErrNotFound) {
		t.Errorf("got %v, want ErrNotFound", err)
	}
}
