package sync

import (
	"context"
	"fmt"
	"hash/fnv"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"time"
)

// WatchOptions configures the long-running --watch mode (§7.5).
//
// Watch reruns Run whenever the registry path or overlay path
// changes. Detection uses fsnotify (§13.11.4); polling is the fallback
// for platforms or filesystems where fsnotify cannot initialize, where
// the poller computes a content-fingerprint over each watched tree and
// reruns the sync when the fingerprint moves. Debounce coalesces
// bursts of edits into a single sync.
type WatchOptions struct {
	// Sync supplies the underlying Run options. RegistryPath is
	// always watched; Target receives the materialized output.
	Sync Options
	// OverlayPath, when non-empty, is watched alongside the
	// registry path so workspace overlay edits trigger a rerun.
	OverlayPath string
	// Period is the poll interval. Defaults to 500ms.
	Period time.Duration
	// Debounce delays a rerun until at least this duration has
	// passed since the last detected change. Defaults to 200ms.
	Debounce time.Duration
}

// WatchEvent reports one Run invocation triggered by Watch. Callers
// receive an event for the initial sync and for every subsequent
// rerun. Err is non-nil when the run itself failed; the watcher
// continues running.
type WatchEvent struct {
	Result *Result
	Err    error
}

// Watch runs an initial sync, then polls the registry and overlay
// paths and reruns Run on every change. Stops when ctx is canceled,
// returning ctx.Err() (typically context.Canceled).
//
// Each rerun emits one WatchEvent on the returned channel. The
// channel is closed when the watcher exits.
func Watch(ctx context.Context, opts WatchOptions) (<-chan WatchEvent, error) {
	if opts.Sync.RegistryPath == "" {
		return nil, ErrNoRegistry
	}
	if opts.Period <= 0 {
		opts.Period = 500 * time.Millisecond
	}
	if opts.Debounce <= 0 {
		opts.Debounce = 200 * time.Millisecond
	}
	// §7.5.4: watch materializes "profile + toggles from the lock file" on
	// startup and re-applies toggles on every event, so every Run on the
	// watch path preserves the lock's toggles rather than clearing them.
	opts.Sync.PreserveToggles = true
	// spec: §7.5.3 — watcher-driven reruns stamp last_synced_by: watch.
	opts.Sync.LastSyncedBy = "watch"

	events := make(chan WatchEvent, 4)
	// §7.5.2 dispatch: a server-source watcher subscribes to the registry's
	// §7.5 change-event stream and reruns on every event; a filesystem
	// source polls the local tree for content changes.
	if isServerSource(opts.Sync.RegistryPath) {
		go runServerWatch(ctx, opts, events)
		return events, nil
	}
	go runWatch(ctx, opts, events)
	return events, nil
}

// runWatch is the watcher goroutine. It owns the events channel and
// closes it on exit.
//
// spec: §13.11.4 — a filesystem source uses fsnotify to watch the registry
// path and the workspace overlay. Polling is the fallback for platforms or
// filesystems where fsnotify cannot initialize (for example a network share
// that does not deliver inotify events).
func runWatch(ctx context.Context, opts WatchOptions, events chan<- WatchEvent) {
	defer close(events)

	emit := func(res *Result, err error) {
		select {
		case events <- WatchEvent{Result: res, Err: err}:
		case <-ctx.Done():
		}
	}

	if tw, err := NewTreeWatcher(opts.Sync.RegistryPath, opts.OverlayPath); err == nil {
		defer tw.Close()
		runFSNotifyWatch(ctx, opts, tw, emit)
		return
	}
	runPollWatch(ctx, opts, emit)
}

// runPollWatch is the poll-based fallback watcher. It computes a content
// fingerprint over the watched trees on each tick and reruns the sync when
// the fingerprint moves, debouncing bursts of edits.
func runPollWatch(ctx context.Context, opts WatchOptions, emit func(*Result, error)) {
	// Initial sync. Capture lastSig BEFORE emitting so a caller that
	// reads the first event and immediately edits the registry can't
	// race the signature snapshot. The previous order (emit, then
	// signature) let any edit performed in response to the initial
	// event land before lastSig captured, so the change was folded
	// into the baseline and the watcher never observed a transition.
	res, err := Run(opts.Sync)
	lastSig := watchSignature(opts.Sync.RegistryPath, opts.OverlayPath)
	emit(res, err)

	ticker := time.NewTicker(opts.Period)
	defer ticker.Stop()

	pending := false
	var pendingSince time.Time
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			sig := watchSignature(opts.Sync.RegistryPath, opts.OverlayPath)
			if sig != lastSig {
				lastSig = sig
				pending = true
				pendingSince = time.Now()
			}
			if pending && time.Since(pendingSince) >= opts.Debounce {
				pending = false
				res, err := Run(opts.Sync)
				emit(res, err)
			}
		}
	}
}

// PathSignature returns a stable content fingerprint over one or more
// filesystem trees, suitable for poll-based change detection. Two
// signatures are equal iff every (path, modtime, size) tuple matches
// across calls. It is exported so other poll-based watchers (the §6.4
// MCP overlay watcher) reuse the same detection logic.
func PathSignature(paths ...string) string {
	return watchSignature(paths...)
}

// watchSignature returns a stable fingerprint of the watched paths.
// Two signatures are equal iff every (path, modtime, size) tuple
// matches across calls. Walks that fail (e.g., transient permission
// errors) contribute their error to the signature so callers see
// later success as a change.
func watchSignature(paths ...string) string {
	h := fnv.New64a()
	for _, p := range paths {
		if p == "" {
			continue
		}
		signOne(h, p)
	}
	return strconv.FormatUint(h.Sum64(), 16)
}

func signOne(h interface{ Write([]byte) (int, error) }, root string) {
	type entry struct {
		path string
		mod  int64
		size int64
		dir  bool
	}
	entries := []entry{}
	walkErr := filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			entries = append(entries, entry{path: path + ":" + err.Error()})
			return nil
		}
		info, ierr := d.Info()
		if ierr != nil {
			entries = append(entries, entry{path: path + ":" + ierr.Error()})
			return nil
		}
		entries = append(entries, entry{
			path: path, mod: info.ModTime().UnixNano(),
			size: info.Size(), dir: d.IsDir(),
		})
		return nil
	})
	sort.Slice(entries, func(i, j int) bool { return entries[i].path < entries[j].path })
	for _, e := range entries {
		fmt.Fprintf(stringWriter{h}, "%s\x00%d\x00%d\x00%t\n",
			e.path, e.mod, e.size, e.dir)
	}
	if walkErr != nil && !os.IsNotExist(walkErr) {
		fmt.Fprintf(stringWriter{h}, "walkerr:%s\n", walkErr.Error())
	}
}

type stringWriter struct {
	w interface{ Write([]byte) (int, error) }
}

func (s stringWriter) Write(p []byte) (int, error) { return s.w.Write(p) }
