// Package source defines the LayerSourceProvider SPI (spec §9.1, §4.6
// "Source types"), plus the built-in local and git providers.
//
// A provider is responsible for snapshotting a layer at a stable
// reference, exposing the artifact tree as a filesystem-like view, and
// declaring its trigger model (webhook / poll / push).
package source

import (
	"context"
	"io/fs"
	"time"

	"github.com/lennylabs/podium/pkg/spi"
)

// TriggerModel declares how the registry should ingest from a source.
type TriggerModel string

// TriggerModel values per §7.3.1 Ingestion triggers.
const (
	TriggerWebhook TriggerModel = "webhook"
	TriggerPoll    TriggerModel = "poll"
	TriggerPush    TriggerModel = "push"
	TriggerManual  TriggerModel = "manual"
)

// Snapshot is one consistent view of a source at a stable reference.
type Snapshot struct {
	// Reference is the source-specific identifier (commit SHA for git,
	// timestamp for local, version ID for object stores).
	Reference string
	// Files exposes the artifact tree as a read-only filesystem.
	Files fs.FS
	// CreatedAt is the snapshot's creation time.
	CreatedAt time.Time
	// HistoryRewritten is true when the caller supplied PriorRef on
	// LayerConfig and the new Reference does not include PriorRef in
	// its history (§7.3.1 force-push tolerance). Always false when
	// PriorRef was empty or the source has no history concept.
	HistoryRewritten bool
}

// Provider is the SPI implementations satisfy. Methods take a
// context.Context first per §9.3.
type Provider interface {
	// ID returns the provider identifier (e.g., "local", "git").
	ID() string
	// Trigger declares how the registry ingests from this provider.
	Trigger() TriggerModel
	// Snapshot returns the current snapshot at the layer's configured
	// reference.
	Snapshot(ctx context.Context, layerConfig LayerConfig) (*Snapshot, error)
}

// LayerConfig captures the per-layer source options. Implementations
// look at the fields relevant to their type and ignore the rest.
type LayerConfig struct {
	// Generic
	ID         string
	Visibility Visibility

	// Git source
	Repo string
	Ref  string
	Root string
	// PriorRef is the last-ingested commit SHA. When set, the Git
	// provider performs a full-history clone and reports
	// Snapshot.HistoryRewritten=true if PriorRef is no longer
	// reachable from Ref (§7.3.1 force-push tolerance).
	PriorRef string

	// Local source
	Path string
}

// Visibility declares who can see a layer (§4.6).
type Visibility struct {
	Public       bool
	Organization bool
	Groups       []string
	Users        []string
}

// Errors returned by providers. Each is a structured *spi.Error carrying its
// §6.10 code so the LayerSourceProvider SPI conforms to the §9.3 "Structured
// errors" constraint.
var (
	// ErrSourceUnreachable wraps a transient fetch failure. The condition is
	// transient, so the structured envelope marks it retryable.
	ErrSourceUnreachable = &spi.Error{Code: "ingest.source_unreachable", Message: "source: unreachable", Retryable: true}
	// ErrInvalidConfig signals an invalid layer config (e.g., git source
	// missing repo:).
	ErrInvalidConfig = &spi.Error{Code: "registry.invalid_argument", Message: "source: invalid_config"}
)
