// Package sign exposes the SignatureProvider SPI (spec §9.1) plus
// the medium-and-above verification policy enforced at
// materialization time (§4.7.9). Built-ins ship a noop provider,
// Sigstore-keyless, and registry-managed-key implementations.
package sign

import (
	"context"
	"fmt"

	"github.com/lennylabs/podium/pkg/manifest"
	"github.com/lennylabs/podium/pkg/spi"
)

// Errors returned by Verify and Sign. Each is a structured *spi.Error carrying
// its §6.10 code so the SignatureProvider SPI conforms to the §9.3 "Structured
// errors" constraint. Tests assert against them via errors.Is, which matches
// the package-level sentinel pointer through fmt.Errorf wrapping.
var (
	// ErrSignatureInvalid signals that the signature does not validate
	// against the artifact's content hash.
	ErrSignatureInvalid = &spi.Error{Code: "materialize.signature_invalid", Message: "signature_invalid"}
	// ErrSignatureMissing signals that an artifact requires a signature
	// (sensitivity ≥ medium under the default policy) but none was
	// provided.
	ErrSignatureMissing = &spi.Error{Code: "materialize.signature_missing", Message: "signature_missing"}
)

// VerificationPolicy controls when Verify enforces the presence of a
// valid signature. Maps to PODIUM_VERIFY_SIGNATURES (spec §6.2).
type VerificationPolicy string

// VerificationPolicy values.
const (
	// PolicyNever skips verification entirely.
	PolicyNever VerificationPolicy = "never"
	// PolicyMediumAndAbove enforces signatures for sensitivity ≥ medium.
	// Default in standard deployments per §6.2.
	PolicyMediumAndAbove VerificationPolicy = "medium-and-above"
	// PolicyAlways enforces signatures for every artifact.
	PolicyAlways VerificationPolicy = "always"
)

// ValidPolicy reports whether p is one of the three recognized
// PODIUM_VERIFY_SIGNATURES values (spec §6.2 / §4.7.9). Callers that
// read the policy from configuration use this to refuse an unknown
// value at startup rather than silently falling through to a skip.
//
// spec: §6.2 — PODIUM_VERIFY_SIGNATURES is never | medium-and-above | always.
func ValidPolicy(p VerificationPolicy) bool {
	switch p {
	case PolicyNever, PolicyMediumAndAbove, PolicyAlways:
		return true
	default:
		return false
	}
}

// Provider is the SPI implementations satisfy.
type Provider interface {
	// ID returns the provider identifier (e.g., "sigstore-keyless").
	ID() string
	// Sign produces a signature over the canonical content hash.
	//
	// spec: §9.3 — context-first so deadlines and cancellation propagate to
	// the network calls a real provider makes (Fulcio, Rekor).
	Sign(ctx context.Context, contentHash string) (string, error)
	// Verify checks that signature is valid for contentHash.
	//
	// spec: §9.3 — context-first for the same reason as Sign.
	Verify(ctx context.Context, contentHash, signature string) error
}

// Noop is a Provider that signs by returning a deterministic placeholder
// and verifies by accepting any matching placeholder. Used as a safe
// default in standalone deployments where signing is opt-in (§13.10).
type Noop struct{}

// ID returns "noop".
func (Noop) ID() string { return "noop" }

// Sign returns a placeholder signature derived from the content hash.
func (Noop) Sign(_ context.Context, contentHash string) (string, error) {
	return "noop:" + contentHash, nil
}

// Verify accepts the placeholder produced by Sign for the same content
// hash and rejects anything else.
func (Noop) Verify(_ context.Context, contentHash, signature string) error {
	want := "noop:" + contentHash
	if signature != want {
		return fmt.Errorf("%w: %q != %q", ErrSignatureInvalid, signature, want)
	}
	return nil
}

// EnforceVerification applies policy to the artifact's sensitivity and
// returns nil when the artifact does not require verification, or the
// result of provider.Verify when it does.
func EnforceVerification(ctx context.Context, policy VerificationPolicy, provider Provider, sensitivity manifest.Sensitivity, contentHash, signature string) error {
	if !needsVerification(policy, sensitivity) {
		return nil
	}
	if signature == "" {
		return fmt.Errorf("%w: sensitivity %q requires a signature", ErrSignatureMissing, sensitivity)
	}
	return provider.Verify(ctx, contentHash, signature)
}

func needsVerification(policy VerificationPolicy, s manifest.Sensitivity) bool {
	switch policy {
	case PolicyAlways:
		return true
	case PolicyMediumAndAbove:
		return s == manifest.SensitivityMedium || s == manifest.SensitivityHigh
	case PolicyNever:
		return false
	default:
		// Fail closed: an unrecognized policy enforces verification
		// rather than silently skipping it. loadConfig refuses such a
		// value at startup (§6.2), so this is defense in depth for any
		// other caller that constructs a policy directly.
		return true
	}
}
